/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author USER
 */
public class Latihan {
    
  public static void main(String[] args){
    int x = 20;
x= 25;
x= 5 + 3;
x= x + 1;
x +=1;
x++;
System.out.println(x);

}
}
