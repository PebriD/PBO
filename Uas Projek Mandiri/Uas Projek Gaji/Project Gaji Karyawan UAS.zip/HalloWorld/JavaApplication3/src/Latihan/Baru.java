/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Latihan;

/**
 *
 * @author USER
 */
public class Baru{
     public.static.void main(String[] args){

     String greeting = "Hello World!";
     System.out.println(greeting);
}

}